import { Request, Response } from 'express';
import Asistencia from '../models/Asistencia';
import moment from 'moment-timezone';
import { Op } from 'sequelize';

export const postAsistencia = async (req: Request, res: Response) => {
    const { rut, sala } = req.body;

    try {
        // Obtener la fecha actual en el formato yyyy-mm-dd y la hora actual en el huso horario de Santiago, Chile
        const today = moment.tz('America/Santiago').format('YYYY-MM-DD');
        const currentTime = moment.tz('America/Santiago').format('HH:mm:ss');

        // Buscar la asistencia con los criterios específicos
        let asistencia = await Asistencia.findOne({
            where: {
                fecha: today,
                profesor_rut: rut,
                hora_inicio: {
                    [Op.lte]: currentTime // Hora inicio <= hora actual
                },
                hora_fin: {
                    [Op.gte]: currentTime // Hora fin >= hora actual
                }
            }
        });

        if (!asistencia) {
            return res.status(404).json({
                msg: `No se encontró asistencia para el rut ${rut} fecha actual`
            });
        }
        if(asistencia.sala==sala){
        asistencia.estado = 'Presente';
        await asistencia.save();
        }
        else{
            asistencia.estado = 'Provisorio';
            asistencia.sala=sala;
            await asistencia.save();
        }
        res.json({
            msg: 'Asistencia encontrada exitosamente y estado actualizado a "presente"!',
            asistencia: asistencia
        });
    } catch (error) {
        res.status(400).json({
            msg: 'Upps ocurrió un error',
            error
        });
    }
};
