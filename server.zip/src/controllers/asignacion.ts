import { Request, Response } from "express";
import Asistencia from '../models/Asistencia';
import { CursosAsignados } from '../models/CursosAsignados';
import { Cursos } from '../models/Cursos';
import { User } from '../models/user';
import { Sala } from '../models/sala'; // Importar el modelo de Sala
import moment from 'moment';
import { Op } from 'sequelize';

// Define una interfaz para el modelo de Cursos
interface Curso {
    nombre: string;
    horaInicio: string;
    horaFin: string;
    dia: number;
    seccion: string;
    // Agrega cualquier otra propiedad que necesites
}

export const setAsignacion = async (req: Request, res: Response) => {
    const { rut, nombre, seccion, provisorio } = req.body;

    try {
        // Obtener el usuario_id usando el rut proporcionado
        const usuario = await User.findOne({
            where: { rut: rut }
        });

        if (!usuario) {
            return res.status(404).json({ message: "Usuario no encontrado" });
        }

        const usuario_id = usuario.dataValues.id;

        if (provisorio === false) {
            // Verificar si ya existe una asignación para el usuario y el curso
            const asignacionExistente = await CursosAsignados.findOne({
                where: {
                    usuario_id: usuario_id,
                    curso_nombre: nombre,
                    curso_seccion: seccion
                }
            });

            if (asignacionExistente) {
                return res.status(400).json({ message: "La asignación ya existe para este usuario y curso" });
            }

            // Crear una nueva fila en la tabla CursosAsignados usando el usuario_id obtenido
            await CursosAsignados.create({
                usuario_id: usuario_id,
                curso_nombre: nombre,
                curso_seccion: seccion
            });

            // Crear filas de asistencias para las próximas dos semanas si no existen
            const crearAsistenciasParaDosSemanas = async () => {
                const hoy = moment();
                const diahoy= moment().format('YYYY-MM-DD');

                const dosSemanasDespues = moment().add(2, 'weeks');

                // Iterar sobre cada día desde hoy hasta dos semanas después
                while (hoy.isSameOrBefore(dosSemanasDespues, 'day')) {
                    const fecha = hoy.format('YYYY-MM-DD');

                    // Verificar si ya existe una asistencia para esta fecha, curso y sección
                    const asistenciaExistente = await Asistencia.findOne({
                        where: {
                            fecha: fecha,
                            curso_nombre: nombre,
                            seccion: seccion
                        }
                    });

                    if (!asistenciaExistente) {
                        // Obtener el curso correspondiente a la asignación y la misma sección
                        let curso: Curso | any = await Cursos.findOne({
                            where: {
                                nombre: nombre,
                                seccion: seccion,
                                dia: hoy.isoWeekday()
                            }
                        });

                        // Si no se encuentra el curso correspondiente, continuar con el siguiente día
                        if (!curso) {
                            hoy.add(1, 'day');
                            continue;
                        }

                        // Obtener la sala correspondiente al curso encontrado
                        const sala = await Sala.findOne({
                            where: { id: curso.sala_id }
                        });

                        // Si no se encuentra la sala correspondiente, continuar con el siguiente día
                        if (!sala) {
                            hoy.add(1, 'day');
                            continue;
                        }
                        let estad="Ausente";
                        if(hoy.format('YYYY-MM-DD')==diahoy){
                            const horaActual = moment().tz('America/Santiago').format('HH:mm:ss');
                            if (moment(horaActual, 'HH:mm:ss').isBetween(moment((curso.horaInicio),'HH:mm:ss'), moment((curso.horaFin),'HH:mm:ss'))){
                                estad="Presente";
                                console.log("llego:"+ estad);
                            }
                            }
                             console.log ("actual:"+estad);
                        

                        // Crear una fila de asistencia para el curso encontrado
                        await Asistencia.create({
                            curso_nombre: curso.nombre,
                            fecha: fecha,
                            hora_inicio: curso.horaInicio,
                            hora_fin: curso.horaFin,
                            dia: curso.dia,
                            estado: estad, // Por defecto, el estado es pendiente
                            profesor_rut: rut, // Usar el rut proporcionado
                            seccion: curso.seccion,
                            sala: sala.dataValues.label // Usar la etiqueta de la sala en lugar del ID de la sala
                        });

                        console.log(`Fila de asistencia creada para ${fecha} - Curso: ${nombre}, Sección: ${seccion}`);
                    }

                    // Moverse al siguiente día
                    hoy.add(1, 'day');
                }
            };

            // Llamar a la función para crear las asistencias para las próximas dos semanas
            await crearAsistenciasParaDosSemanas();

            // Si se crea la fila con éxito, enviar una respuesta
            return res.status(200).json({ message: "Asignación creada exitosamente y filas de asistencias generadas para las próximas dos semanas" });
        } else {
            // Caso provisorio verdadero
            const hoy = moment();
            const diaActual = hoy.isoWeekday();
            const horaActual = moment().tz('America/Santiago').format('HH:mm:ss');

            // Buscar el curso que coincida con el nombre, seccion, día actual y cuyo rango de horas contenga la hora actual
            const curso = await Cursos.findOne({
                where: {
                    nombre: nombre,
                    seccion: seccion,
                    dia: diaActual,
                    horaInicio: { [Op.lte]: horaActual },
                    horaFin: { [Op.gte]: horaActual }
                }
            });

            if (curso) {
                // Obtener la sala correspondiente al curso encontrado
                const sala = await Sala.findOne({
                    where: { id: curso.dataValues.sala_id }
                });

                if (!sala) {
                    return res.status(404).json({ message: "Sala no encontrada para el curso actual" });
                }

                // Crear una fila de asistencia para el curso encontrado
                await Asistencia.create({
                    curso_nombre: curso.dataValues.nombre,
                    fecha: hoy.format('YYYY-MM-DD'),
                    hora_inicio: curso.dataValues.horaInicio,
                    hora_fin: curso.dataValues.horaFin,
                    dia: curso.dataValues.dia,
                    estado: 'Presente', // Por defecto, el estado es pendiente
                    profesor_rut: rut, // Usar el rut proporcionado
                    seccion: curso.dataValues.seccion,
                    sala: sala.dataValues.label // Usar la etiqueta de la sala en lugar del ID de la sala
                });

                return res.status(200).json({ message: "Asistencia provisoria creada exitosamente para el curso actual" });
            } else {
                return res.status(404).json({ message: "No hay cursos coincidentes con los criterios actuales" });
            }
        }
    } catch (error) {
        // Si hay algún error, enviar una respuesta de error
        console.log(error);
        return res.status(500).json({ message: "Error al crear la asignación", error: error });
    }
};