import { Request, Response } from 'express';
import { Cursos } from '../models/Cursos';
import { Sala } from '../models/sala';
import { Area } from '../models/Area';
import sequelize from '../db/conection';

export const upload = async (req: Request, res: Response) => {
  try {
    const { headers, data } = req.body as { headers: string[], data: any[][] };

    // Verificar si hay datos
    if (!data || !headers) {
      return res.status(400).json({ message: "Missing data or headers" });
    }

    const nombreIndex = headers.indexOf('NOMBRE');
    const seccionIndex = headers.indexOf('SECCION');
    const salaIndex = headers.indexOf('Sala');
    const edificioIndex = headers.indexOf('Edificio');
    const horaInicioIndex = headers.indexOf('HORA INICIO');
    const horaFinIndex = headers.indexOf('HORA FIN');
    const diaIndex = headers.indexOf('DIA');

    if (nombreIndex === -1 || seccionIndex === -1 || salaIndex === -1 || edificioIndex === -1) {
      return res.status(400).json({ message: "Missing required headers" });
    }

    // Borra todos los datos de las tablas y reinicia los autoincrementables
    await sequelize.transaction(async (t) => {
      await Cursos.destroy({ where: {} });
      await Sala.destroy({ where: {} });
      await Area.destroy({ where: {} });

      // Obtener nombres únicos de áreas
      const uniqueAreas: string[] = [...new Set(data.map((row: any) => row[edificioIndex] as string))];

      // Crear áreas
      const areas = await Area.bulkCreate(uniqueAreas.map((nombre: string) => ({ nombre: nombre })), { returning: true, transaction: t });
      const areaMap = new Map(uniqueAreas.map((nombre: string, index: number) => [nombre, (areas[index] as any).id]));

      // Preparar datos para la creación de salas y cursos
      const salasData: { label: string; area_id: number }[] = [];
      const cursosData: { nombre: string; seccion: string; horaInicio: string; horaFin: string; dia: number; sala_id: number | null }[] = [];

      for (const row of data) {
        salasData.push({ label: row[salaIndex], area_id: areaMap.get(row[edificioIndex] as string) });
      }

      // Crear salas y mapear las IDs
      const salas = await Sala.bulkCreate(salasData, { returning: true, transaction: t });
      const salaMap = new Map(salas.map((sala: any) => [sala.label, sala.id]));

      // Crear datos de cursos incluyendo sala_id
      for (const row of data) {
        cursosData.push({
          nombre: row[nombreIndex],
          seccion: row[seccionIndex],
          horaInicio: row[horaInicioIndex] || "sin definir",
          horaFin: row[horaFinIndex] || "sin definir",
          dia: row[diaIndex],
          sala_id: salaMap.get(row[salaIndex]) || null
        });
      }

      // Crear cursos
      await Cursos.bulkCreate(cursosData, { transaction: t });
    });

    res.json({
      message: "Data received and processed successfully"
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};
