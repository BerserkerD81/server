import { Request, Response } from "express";
import  Asistencia  from "../models/Asistencia";
import { Op } from "sequelize";


export const getAsistencia = async (req: Request, res: Response): Promise<void> => {
    try {
        const data = await Asistencia.findAll({});
        res.json(data);
    } catch (error) {
        res.status(400).json({
            msg: 'Error al obtener la asistencia',
            error,
        });
    }
};

export const asistenciaManual = async (req: Request, res: Response) => {

    const { curso_nombre, fecha, hora_inicio, hora_fin, dia, estado, motivo, profesor_rut, seccion, sala } = req.body;

    try {
        console.log(req.body);

        // Buscar si ya existe una asistencia para el profesor, el curso y la fecha dada
        let asistencia = await Asistencia.findOne({
            where: {
                fecha: fecha,
                profesor_rut: profesor_rut,
                hora_inicio: {
                    [Op.lte]: hora_inicio // Hora inicio <= hora actual
                },
                hora_fin: {
                    [Op.gte]: hora_fin // Hora fin >= hora actual
                }
            }
        });

        if (asistencia) {
            // Si existe, actualizar la entrada existente
            asistencia.estado = 'Presente';
            asistencia.sala =sala;
            await asistencia.save();

            res.json({
                msg: `Asistencia actualizada exitosamente`
            });
        } else {
            // Si no existe, crear una nueva entrada
            await Asistencia.create({
                curso_nombre,
                fecha,
                hora_inicio,
                hora_fin,
                dia,
                estado,
                motivo,
                profesor_rut,
                seccion,
                sala
            });

            res.json({
                msg: `Ingreso registrado exitosamente`
            });
        }
    } catch (error) {
        res.status(400).json({
            msg: "Error al ingresar", error
        });
    }
};
