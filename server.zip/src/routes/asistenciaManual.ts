import { Router } from 'express';
import { asistenciaManual, getAsistencia } from '../controllers/asistencia';

const router = Router();

router.post('/', asistenciaManual)
router.get('/getAsistencia', getAsistencia)

export default router;