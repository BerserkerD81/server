import{Router} from "express";
import { postAsistencia } from "../controllers/asistir";

const router = Router()

router.post("/",postAsistencia)


export default router;