import express from "express";
import routerProduct from "../routes/product";
import routesUser from "../routes/user";
import routesUpload from "../routes/upload";
import routesJustify from "../routes/Justify";
import routesHistory from "../routes/history";
import routesCursos from "../routes/Cursos";
import rouresAsignacion from "../routes/asignacion";
import routesAsistir from "../routes/asistir";
import routesAsistenciaManual from "../routes/asistenciaManual";
import routesSala  from "../routes/sala";
import routesExcepcion from "../routes/excepcion";
import routeUpdate from "../routes/updateAsistencia";
import cors from 'cors';
import { User } from "./user";

class Server {
    private app: express.Application;
    private port: string | undefined;

    constructor() {
      this.app = express();
      this.port = process.env.puerto;
      this.listen();
      this.middlewares();
      this.routes();
      this.dbConnect();
    }

    listen() {
        this.app.listen(this.port, () => {
            console.log("App corriendo en el puerto " + this.port);
        });
    }

    routes() {
        this.app.use("/api/products", routerProduct);
        this.app.use("/api/users", routesUser);
        this.app.use("/upload", routesUpload);
        this.app.use("/justify",routesJustify);
        this.app.use("/history",routesHistory);
        this.app.use("/cursos",routesCursos);
        this.app.use("/asignacion",rouresAsignacion);
        this.app.use("/asistir",routesAsistir);
        this.app.use("/asistencia", routesAsistenciaManual);
        this.app.use("/salas",routesSala);
        this.app.use("/excepcion",routesExcepcion);
        this.app.use("/updateAsistencia", routeUpdate);

    }

    middlewares() {
        // Configura el límite de tamaño de carga útil
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.urlencoded({ limit: '10mb', extended: true }));
        this.app.use(cors());
    }

    async dbConnect() {
        try {
            await User.sync();
        } catch(error) {
            console.log("No se pudo conectar a la base de datos", error);
        }
    }
}

export default Server;